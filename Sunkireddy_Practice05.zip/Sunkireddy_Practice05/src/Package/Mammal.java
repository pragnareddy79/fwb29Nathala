/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Package;

/**
 *
 * @author S545406
 */
public class Mammal extends Animal{
   
    /**
     * This is method of String
     * @return Mammal Sound
     */
    public String makeSound(){
         return "Mammal Sound";
    }
}
