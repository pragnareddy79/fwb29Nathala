/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Package;

/**
 *
 * @author S545406
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
     // TODO code application logic here
     //This is constructor of animal and creating an object
     Animal animal=new Animal();
     //This prints the sound of animal and gets the method from animal class
     System.out.println("sound of the animal:"+animal.makeSound());
     //constructor of mammal and object is created
     Mammal mammal=new Mammal();
     //It prints the sound of mammal and calls the method from mammal class which inherits the animal class is superclass
     System.out.println("sound  of the mammal:"+mammal.makeSound());
     //constructor of grizzlybear and object is created
     GrizzlyBear grizzlybear=new GrizzlyBear();
     //mammal object assigned to grizzlybear
     mammal=grizzlybear;
     //It prints the sound of grizzlybear and calls the method from mammal class because to print the sounds which inherits the superclass
      System.out.println("sound of grizzlybear:"+mammal.makeSound());
     
    }
    
}
